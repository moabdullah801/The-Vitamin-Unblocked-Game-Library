<div align="center">
<h1>Now.gg-Roblox</h1>
<h3>Easily access roblox at school!</h3>
This allows you to play Roblox through Now.gg all you have to do is run the link though a proxy!
</div>
<h2>Demo:</h2>
<a href="https://goguardian.cloud">https://goguardian.cloud</a>
<p>Make sure to run though a proxy!</p>

<a href="https://www.youtube.com/@BlazerHM?sub_confirmation=1">Subscribe To Blazer</a>
